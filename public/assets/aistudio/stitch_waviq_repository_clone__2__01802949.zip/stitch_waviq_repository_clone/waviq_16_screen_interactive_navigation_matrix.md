# دليل الربط التفاعلي والتنقل المباشر (WAVIQ Interactive Navigation Matrix)
### نظام التصميم: Sonic Brutalism // Nothing OS & Glyph Interface (`#ff2a2a`)

يوثق هذا الدليل شبكة روابط الانتقال اللمسية (Navigation Links & Action Triggers) بين الشاشات الـ 16 المعتمدة، لربط شريط التنقل السفلي (Bottom Tab Bar)، الأزرار التفاعلية (Action Triggers)، ومسارات التدفق عبر التطبيق.

---

## 1. شبكة التنقل الأساسية عبر التبويبات السفلية (Bottom Navigation Tabs)
الشاشات الـ 16 تشترك في أربعة تبويبات رئيسية في الشريط السفلي:

| التبويب | الأيقونة والاسم | الوجهة الرئيسية الافتراضية | الشاشات التابعة للتبويب |
| :--- | :--- | :--- | :--- |
| **Tab 1** | `ANALYZE` (التحليل) | `{{DATA:SCREEN:SCREEN_61}}` (Audio Track Inspector) | `SCREEN_61`, `SCREEN_55`, `SCREEN_59`, `SCREEN_57` |
| **Tab 2** | `ENHANCE` (التعزيز) | `{{DATA:SCREEN:SCREEN_16}}` (Autonomous AI Engine) | `SCREEN_16`, `SCREEN_14`, `SCREEN_40`, `SCREEN_52` |
| **Tab 3** | `STUDIO` (الاستوديو) | `{{DATA:SCREEN:SCREEN_8}}` (AI Studio Pro Suite) | `SCREEN_8`, `SCREEN_6`, `SCREEN_30`, `SCREEN_22` |
| **Tab 4** | `LIBRARY` (المكتبة والتصدير) | `{{DATA:SCREEN:SCREEN_38}}` (My Library Tactile) | `SCREEN_38`, `SCREEN_28`, `SCREEN_4`, `SCREEN_24` |

---

## 2. جدول الروابط التفاعلية المتسلسلة بين الشاشات (Action-to-Screen Mapping)

### المسار 1: التحليل والرصد الطيفي (Analyze Stage)
1. **من `{{DATA:SCREEN:SCREEN_61}}` (Audio Track Inspector)**:
   - **الزر**: `ANALYZE LIVE SPECTRUM // فحص الطيف الحي`
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_55}}` (Live Scope Analyzer)
2. **من `{{DATA:SCREEN:SCREEN_55}}` (Live Scope Analyzer)**:
   - **الزر**: `PARAMETRIC EQ // ضبط الترددات`
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_59}}` (Parametric EQ & Filters)
3. **من `{{DATA:SCREEN:SCREEN_59}}` (Parametric EQ & Filters)**:
   - **الزر**: `VIEW AUDIT REPORT // تقرير التحليل`
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_57}}` (Analysis Reports & History)
4. **من `{{DATA:SCREEN:SCREEN_57}}` (Analysis Reports & History)**:
   - **الزر**: `ENGAGE AI ENGINE // الانتقال للمعالجة الذاتية`
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_16}}` (Autonomous AI Engine)

---

### المسار 2: المعالجة الذاتية والتعزيز السريع (Autonomous AI & Enhance)
5. **من `{{DATA:SCREEN:SCREEN_16}}` (Autonomous AI Engine - Turbo/Deep)**:
   - **الزر**: `EXECUTE DEEP MASTER // بدء المعالجة العميقة`
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_14}}` (Deep 3.5s Processing)
6. **من `{{DATA:SCREEN:SCREEN_14}}` (Deep 3.5s Processing)**:
   - **الحدث**: اكتمال المعالجة (أو النقر على `FINE TUNE ENHANCE`)
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_40}}` (Auto Enhance Tactile Edition)
7. **من `{{DATA:SCREEN:SCREEN_40}}` (Auto Enhance - Tactile Edition)**:
   - **الزر**: `A/B AUDIT TEST // مقارنة الصوت الفورية`
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_52}}` (Original vs Enhanced)
8. **من `{{DATA:SCREEN:SCREEN_52}}` (Original vs Enhanced)**:
   - **الزر**: `OPEN PRO STUDIO // فتح استوديو الماسترنج`
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_8}}` (AI Studio & Pro Mastering Suite)

---

### المسار 3: استوديو الماسترنج الاحترافي وعزل الآلات (AI Studio Pro Suite)
9. **من `{{DATA:SCREEN:SCREEN_8}}` (AI Studio & Pro Mastering Suite)**:
   - **الزر**: `AUDIT MASTER (BYPASS / ENGAGE) // معاينة الماستر الفورية`
   - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_6}}` (AI Studio Mastering - Bypass vs Engaged)
10. **من `{{DATA:SCREEN:SCREEN_6}}` (AI Studio Mastering - Bypass vs Engaged)**:
    - **الزر**: `HARDWARE & VU SETTINGS // إعدادات الـ VU والعتاد`
    - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_30}}` (Hardware Settings & Interactive Glyph VU)

---

### المسار 4: إعدادات العتاد ومصفوفة الصيغ (Hardware & Format Matrix)
11. **من `{{DATA:SCREEN:SCREEN_30}}` (Hardware Settings & Interactive Glyph VU)**:
    - **الزر**: `OPEN TRANSCODE MATRIX // مصفوفة الصيغ`
    - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_22}}` (Hardware Settings & Transcode Matrix)
12. **من `{{DATA:SCREEN:SCREEN_22}}` (Hardware Settings & Transcode Matrix)**:
    - **الزر**: `START EXPORT // بدء تصدير الملف`
    - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_28}}` (Interactive Export Telemetry Modal)

---

### المسار 5: المراقبة والتصدير النهائي والمكتبة (Final Export & Library)
13. **من `{{DATA:SCREEN:SCREEN_28}}` (Interactive Export Telemetry Modal)**:
    - **الحدث**: وصول العداد إلى 100% (أو النقر على `VIEW COMPLETE MASTER`)
    - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_4}}` (Final Master Export & Save Complete)
14. **من `{{DATA:SCREEN:SCREEN_4}}` (Final Master Export & Save Complete)**:
    - **الزر**: `⚡ OPEN IN MY LIBRARY // الانتقال للمكتبة والمشغل`
    - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_38}}` (WAVIQ - My Library Tactile Edition)
15. **من `{{DATA:SCREEN:SCREEN_38}}` (My Library Tactile Edition)**:
    - **الزر**: النقر على شريط المشغل الصوتي المدمج السفلي (Mini Player Deck)
    - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_24}}` (Live Master Audio Player - Full Deck)
16. **من `{{DATA:SCREEN:SCREEN_24}}` (Live Master Audio Player)**:
    - **الزر**: `CLOSE PLAYER // أو العودة للمكتبة / عودة للاستوديو`
    - **ينقل إلى**: `{{DATA:SCREEN:SCREEN_38}}` أو `{{DATA:SCREEN:SCREEN_8}}`

---

## 3. محاكاة الروابط المدمجة داخل واجهات الشاشات
يمكن للمستخدم النقر على الأزرار المحددة في كل شاشة للانتقال السلس، مع احتفاظ كل شاشة بهوية **Nothing OS** والنبضات اللمسية النيونية (`#ff2a2a`).
