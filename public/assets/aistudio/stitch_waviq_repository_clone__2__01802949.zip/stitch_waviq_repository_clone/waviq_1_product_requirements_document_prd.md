# WAVIQ (1) — Product Requirements Document (PRD) & Product Brief
**Document Version:** 1.0.0  
**Status:** Approved / Ready for Engineering  
**Design Identity:** Nothing OS & Glyph Interface // Sonic Brutalism (`#ff2a2a`)  
**Target Architecture:** Mobile (iOS / Android / React Native / PWA) & On-Device NPU Audio Core  

---

## 1. Executive Summary & Vision

### 1.1 Product Pitch
**WAVIQ (1)** is a pro-grade, autonomous AI audio engineering and mastering mobile suite built inside an industrial Nothing OS aesthetic. It empowers music producers, podcasters, and content creators to analyze, enhance, master, and transcode audio with studio fidelity (up to 96kHz / 32-bit float) in under 3.5 seconds directly on-device with zero server dependency.

### 1.2 Core Pillars
1. **Autonomous Neural DSP**: Zero-friction audio enhancement with multi-pass neural reconstruction (Turbo 0.8s vs Deep 3.5s).
2. **Studio Hardware Telemetry**: Live oscilloscope, real-time 2048-point FFT spectral analysis, True Peak limiter (-0.1 dBTP), and EBU R128 LUFS metering.
3. **Tactile & Glyph Integration**: Mechanical haptic feedback, real-time VU ladder sync, and hardware-inspired industrial controls.
4. **100% On-Device & Private**: Air-gapped offline processing leveraging the local Neural Processing Unit (NPU).

---

## 2. Target Users & Problem Statements

| User Persona | Core Problem | How WAVIQ Solves It |
| :--- | :--- | :--- |
| **Mobile Music Producers & Beatmakers** | DAWs are bulky; mobile mastering apps are either overly simplistic or clip/distort audio. | Analog-modeled DSP chain (Studer A820 tape saturation, True Peak limiter) with A/B zero-latency bus switching. |
| **Podcasters & Creators** | Background room rumble, sibilance, uneven vocal dynamics, and strict loudness compliance across platforms. | One-tap Vocal Enhancement, automatic de-essing, dynamic leveling to target LUFS (-14 / -16), and instant MP3/WAV export. |
| **Field Sound Engineers** | Lack of portable, instant spectral auditing and phase correlation telemetry. | Precision live scope analyzer, FFT 1/3 octave visualizer, and phase correlation meter (+0.92 in-phase lock). |

---

## 3. Product Architecture (The 4x4 Screen Matrix)

WAVIQ (1) is architected around an exact 16-screen ecosystem divided evenly into four functional stages:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             WAVIQ (1) NOTHING OS                            │
├───────────────────┬───────────────────┬───────────────────┬─────────────────┤
│    1. ANALYZE     │    2. ENHANCE     │     3. STUDIO     │   4. LIBRARY    │
├───────────────────┼───────────────────┼───────────────────┼─────────────────┤
│ 01. Inspector     │ 05. AI Engine     │ 09. Mastering     │ 13. Transcode   │
│ 02. Live Scope    │ 06. Deep 3.5s     │ 10. Stem Separate │ 14. Export Modal│
│ 03. Parametric EQ │ 07. Tactile Deck  │ 11. Bypass vs Eng │ 15. Master Done │
│ 04. Audit Reports │ 08. A/B Compare   │ 12. Glyph VU Deck │ 16. Player Deck │
└───────────────────┴───────────────────┴───────────────────┴─────────────────┘
```

### Module 1: Analyze & Telemetry (Tab 1)
- **Screen 01 — Audio Track Inspector**: File metadata, bit-depth (16/24/32-bit float), sample rate (44.1k to 96k), codec detection, and dynamic range evaluation.
- **Screen 02 — Live Scope Analyzer**: Dynamic oscilloscope with glowing analog CRT phosphor effect, frequency grid (20Hz - 20kHz), and peak-hold indicators.
- **Screen 03 — Parametric EQ & Filters**: Multi-band parametric curve editing, high/low shelf filters, resonance notch filtering, and real-time visual feedback.
- **Screen 04 — Analysis Reports & History**: Audit logs, dynamic crest factor comparison, LUFS compliance badges (Spotify, Apple Music, YouTube), and phase balance charts.

### Module 2: Autonomous AI & Enhance (Tab 2)
- **Screen 05 — Autonomous AI Engine**: Primary launcher with mode selector (`Turbo 0.8s` for instant social audio vs `Deep 3.5s` for commercial releases).
- **Screen 06 — Deep 3.5s Processing**: Real-time NPU telemetry displaying neural pass steps: Noise De-hum → Transient Shaping → Harmonic Synthesis → Bus Glue.
- **Screen 07 — Auto Enhance Tactile Deck**: Rotary tactile feel, dial intensity slider, and one-touch quick enhance with physical haptics.
- **Screen 08 — Original vs Enhanced (A/B)**: Instant waveform comparison split-screen with seamless crossfade preview.

### Module 3: Pro Mastering & DSP Suite (Tab 3)
- **Screen 09 — AI Studio Pro Suite**: Multi-processor mastering console (Sub-bass exciter, Air band lift, Multiband compressor, Brickwall limiter).
- **Screen 10 — 4-Way Stem Separation**: AI neural isolation of Vocals, Drums, Bass, and Other Instruments with Solo/Mute toggle switches.
- **Screen 11 — Bypass vs Engaged (Zero-Latency A/B)**: Dedicated hardware toggle switch with 15ms crossfade preventing speaker pop.
- **Screen 12 — Hardware & Glyph VU Sync**: Real-time 12-segment stereo LED ladder meter synced with device rear Glyph LEDs and clip detection.

### Module 4: Transcode, Export & Library (Tab 4)
- **Screen 13 — Transcode & Encoding Matrix**: Output format selection (WAV 32-bit float, FLAC 24-bit 96kHz, MP3 320kbps, AAC 256kbps).
- **Screen 14 — Export Telemetry Modal**: Progress indicator, disk write speed telemetry, buffer flush status, and cryptographic SHA-256 hash generation.
- **Screen 15 — Master Export 100% Complete**: Final output verification, loudness confirmation (-14.0 LUFS, -0.1 dBTP), and direct DAW/Cloud routing.
- **Screen 16 — My Library & Master Player**: Offline storage archive, interactive waveform scrubbing, playback transport controls, and batch management.

---

## 4. Technical Specifications & DSP Pipeline

### 4.1 Audio Engine Specifications
- **Core Engine**: Web Audio API (Web/PWA) / CoreAudio (iOS) / Oboe C++ (Android).
- **Internal Processing**: 64-bit IEEE floating-point arithmetic.
- **Sampling Rates**: 44.1 kHz, 48.0 kHz, 88.2 kHz, 96.0 kHz.
- **Latency Target**: `< 2.5 ms` roundtrip buffer latency.
- **Tape Saturation Model**: Non-linear hyperbolic tangent curve with odd-harmonic synthesis (simulating Studer A820 1/2" 30 IPS analog tape).
- **Limiter Specs**: True-Peak intersample lookahead brickwall limiter with adjustable release (40ms - 120ms) locked to `-0.1 dBTP` ceiling.

### 4.2 System Performance Targets
- **Max Processing Time**: `≤ 3.5 seconds` for a standard 3.5-minute audio track on mobile NPU.
- **RAM Footprint**: Under 180MB peak usage during 96kHz rendering.
- **Battery Drain**: `< 1.2%` battery consumption per 10 mastered tracks.
- **Offline Reliability**: 100% functionality without internet connection.

---

## 5. UI/UX Design System Specification

### 5.1 Color Palette
- **Primary Glyph Accent**: `#ff2a2a` (Nothing Signature Neon Red)
- **Subtle Red Glow**: `rgba(255, 42, 42, 0.45)`
- **True Carbon Surface**: `#0c0c0c` / `#121212`
- **Elevated Hardware Cards**: `#181818` / `#222222`
- **Telemetry Active / In-Phase**: `#00e676` (Bit-perfect Green)
- **Warning Headroom**: `#ffab00` (Amber)
- **Digital Clip Limit**: `#ff1744` (Pure Clip Red)
- **Border Structure**: `rgba(255, 255, 255, 0.08)`

### 5.2 Typography & Aesthetics
- **Display & Monospace**: `Space Grotesk`, `JetBrains Mono`, and Dot-Matrix emulation (`N-Dot`).
- **Tactile Physics**: Micro-interactions with `scale(0.96)` active states and native 15ms vibrator haptics.
- **Accessibility**: Full compliance with WCAG AAA contrast ratio on dark backgrounds and strict `prefers-reduced-motion` fallbacks.

---

## 6. Release Roadmap & Success Metrics

### 6.1 Phased Milestones
- **Phase 1 (MVP)**: Core Audio Engine + Auto Enhance + 4x4 Screen UI with mock DSP pipeline.
- **Phase 2 (Alpha)**: Full local NPU model integration for 4-pass neural reconstruction + Stem separation.
- **Phase 3 (Beta)**: Glyph Interface SDK sync (Nothing Phone 1/2 integration) + Bit-perfect export verification.
- **Phase 4 (Production)**: Public launch on App Store, Google Play, and standalone PWA.

### 6.2 Key Performance Indicators (KPIs)
- **Render Completion Rate**: `> 98.5%` without memory crashes.
- **Master Quality Satisfaction**: `> 90%` A/B preference score compared to raw track.
- **Export Retention**: Over 5 exported tracks per active user per week.
