# وثيقة تسليم التصميم ومواصفات الكود للمطورين (WAVIQ Developer Handoff & Design System Spec)
### الهوية البصرية: Nothing OS & Glyph Interface // Sonic Brutalism
### رمز النظام اللوني الرئيسي: `#ff2a2a` (Glyph Red) | الخلفية: `#131313` (Tactile Matte Black)

---

## 1. رموز التصميم وتوكنز CSS/Tailwind (Design Tokens)

### أ. لوحة الألوان (Color Tokens)
```css
:root {
  /* Surfaces & Backgrounds */
  --color-surface: #131313;
  --color-surface-dim: #0e0e0e;
  --color-surface-bright: #1f1f1f;
  --color-surface-container-low: #181818;
  --color-surface-container-mid: #222222;
  --color-surface-container-high: #2a2a2a;
  
  /* Borders & Dividers */
  --color-border-subtle: rgba(255, 255, 255, 0.08);
  --color-border-active: rgba(255, 42, 42, 0.4);
  --color-border-glow: #ff2a2a;

  /* Glyph & Accent Colors */
  --color-glyph-primary: #ff2a2a;          /* Nothing Iconic Neon Red */
  --color-glyph-primary-glow: rgba(255, 42, 42, 0.35);
  --color-glyph-secondary: #ffffff;        /* Pure White Dot */
  --color-glyph-muted: #757575;            /* Mid Grey Telemetry */
  --color-glyph-dark: #3a3a3a;             /* Deactivated LED */

  /* Telemetry Indicators */
  --color-status-success: #00e676;         /* Bit-perfect Green */
  --color-status-warning: #ffab00;         /* Jitter Alert */
  --color-status-clip: #ff1744;            /* DSP True-Peak Clip */
}
```

### ب. تكوين Tailwind Config المقترح (`tailwind.config.js`)
```javascript
module.exports = {
  theme: {
    extend: {
      colors: {
        waviq: {
          surface: '#131313',
          dim: '#0e0e0e',
          card: '#1a1a1a',
          border: 'rgba(255, 255, 255, 0.08)',
          glyph: '#ff2a2a',
          'glyph-glow': 'rgba(255, 42, 42, 0.35)',
          telemetry: '#888888',
        }
      },
      fontFamily: {
        mono: ['"Space Grotesk"', 'monospace'],
        display: ['"Space Grotesk"', 'sans-serif'],
      },
      boxShadow: {
        'glyph-red': '0 0 16px rgba(255, 42, 42, 0.45)',
        'glyph-sm': '0 0 8px rgba(255, 42, 42, 0.3)',
        'tactile-switch': 'inset 0 1px 1px rgba(255,255,255,0.1), 0 2px 4px rgba(0,0,0,0.8)',
      },
      animation: {
        'pulse-glyph': 'pulseGlyph 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'vu-sweep': 'vuSweep 1.8s ease-in-out infinite alternate',
      },
      keyframes: {
        pulseGlyph: {
          '0%, 100%': { opacity: '1', filter: 'drop-shadow(0 0 8px #ff2a2a)' },
          '50%': { opacity: '0.4', filter: 'drop-shadow(0 0 2px #ff2a2a)' },
        },
        vuSweep: {
          '0%': { transform: 'rotate(-45deg)' },
          '100%': { transform: 'rotate(28deg)' },
        }
      }
    }
  }
}
```

---

## 2. مواصفات التايبوغرافي (Typography Spec)
- **الخط الأساسي**: `Space Grotesk` (مفتوح المصدر من Google Fonts) مع دعم كامل لخصائص الأرقام المتناسقة `font-variant-numeric: tabular-nums`.
- **أحجام النصوص القياسية**:
  * **HERO / HUD Numbers**: `36px - 44px` | `font-bold` | `letter-spacing: -0.04em`
  * **Module Headers**: `14px - 16px` | `font-bold` | `uppercase` | `letter-spacing: 0.08em`
  * **Telemetry Labels**: `11px - 12px` | `font-mono` | `text-gray-400` | `uppercase`
  * **Micro Metrics / Timestamps**: `9px - 10px` | `font-mono` | `tracking-widest`

---

## 3. مواصفات المكونات الأساسية وتوصيف الكود (Component Specifications)

### أ. زر الإجراء التكتيلي المضيء (Tactile Glyph Primary Button)
```html
<button class="relative w-full py-4 px-6 bg-[#ff2a2a] hover:bg-[#ff3b3b] active:scale-[0.98] transition-all duration-150 rounded-lg text-black font-mono font-bold tracking-wider text-sm flex items-center justify-center gap-3 shadow-[0_0_20px_rgba(255,42,42,0.4)] cursor-pointer">
  <span class="w-2.5 h-2.5 rounded-full bg-white shadow-[0_0_6px_#ffffff] animate-ping"></span>
  <span class="tracking-widest uppercase">EXECUTE DEEP MASTER // بدء المعالجة</span>
</button>
```

### ب. مفتاح التبديل الميكانيكي (Mechanical A/B Toggle - Bypass vs Engaged)
```html
<div class="flex items-center bg-[#0e0e0e] border border-white/10 p-1 rounded-md font-mono text-xs">
  <button class="flex-1 py-2 px-3 rounded text-neutral-400 hover:text-white transition-colors duration-150 text-center tracking-wider font-semibold">
    BYPASS <span class="text-[10px] opacity-60">RAW</span>
  </button>
  <button class="flex-1 py-2 px-3 rounded bg-[#1e1e1e] border border-[#ff2a2a]/40 text-white text-center tracking-wider font-bold shadow-[0_0_10px_rgba(255,42,42,0.25)] flex items-center justify-center gap-1.5">
    <span class="w-1.5 h-1.5 rounded-full bg-[#ff2a2a] shadow-[0_0_6px_#ff2a2a]"></span>
    ENGAGED <span class="text-[10px] text-[#ff2a2a]">NPU</span>
  </button>
</div>
```

### ج. مؤشر الـ VU الرقمي وشرائط الـ LED (LED Segment Meter)
```html
<div class="flex gap-1 items-center h-4 bg-black/60 p-1 rounded border border-white/5">
  <!-- Safe Green/White Dots -->
  <div class="w-2 h-full bg-white/90 rounded-[1px]"></div>
  <div class="w-2 h-full bg-white/90 rounded-[1px]"></div>
  <div class="w-2 h-full bg-white/90 rounded-[1px]"></div>
  <div class="w-2 h-full bg-white/50 rounded-[1px]"></div>
  <!-- Mid Warning -->
  <div class="w-2 h-full bg-white/20 rounded-[1px]"></div>
  <!-- Peak Glyph Red -->
  <div class="w-2 h-full bg-[#ff2a2a] shadow-[0_0_8px_#ff2a2a] rounded-[1px] animate-pulse"></div>
</div>
```

### د. شريط التنقل السفلي الثابت (Fixed Bottom Tab Bar)
```html
<nav class="fixed bottom-0 left-0 right-0 h-16 bg-[#131313]/95 backdrop-blur-md border-t border-white/10 flex items-center justify-around px-4 z-50">
  <!-- Tab 1: Analyze -->
  <button class="flex flex-col items-center gap-1 text-white/50 hover:text-white">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/></svg>
    <span class="text-[9px] font-mono tracking-widest">ANALYZE</span>
  </button>
  <!-- Tab 2: Enhance -->
  <button class="flex flex-col items-center gap-1 text-white/50 hover:text-white">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/></svg>
    <span class="text-[9px] font-mono tracking-widest">ENHANCE</span>
  </button>
  <!-- Tab 3: Studio (Active) -->
  <button class="flex flex-col items-center gap-1 text-[#ff2a2a]">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
    <span class="text-[9px] font-mono font-bold tracking-widest">STUDIO</span>
    <span class="w-1 h-1 rounded-full bg-[#ff2a2a] shadow-[0_0_4px_#ff2a2a]"></span>
  </button>
  <!-- Tab 4: Library -->
  <button class="flex flex-col items-center gap-1 text-white/50 hover:text-white">
    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
    <span class="text-[9px] font-mono tracking-widest">LIBRARY</span>
  </button>
</nav>
```

---

## 4. تكامل Web Audio API ومحرك المعالجة البرمجي (Audio Engine Architecture)
للمطورين المسؤولين عن تكامل الصوت، ينصح بالبنية العقدية التالية:
```
[AudioBufferSourceNode]
          │
          ▼
 [LowPass / HighPass EQ]
          │
    ┌─────┴──────────────────┐
    ▼                        ▼
[Bypass Gain (Raw)]    [DSP Chain Node]
 (Gain: 0.5)            ├── Multiband Compressor
                        ├── Stereo Haas Panner
                        ├── WaveShaper (Studer Saturation)
                        └── DynamicsCompressor (True-Peak Limiter)
                             │
                             ▼
                     [Engaged Gain (Master)]
                             │
    ┌────────────────────────┘
    ▼
[AudioContext.destination]
```

---

## 5. مواصفات التوافق وإمكانية الوصول (Accessibility & Motion Guidelines)
- **Reduced Motion**: يجب تعطيل وميض الـ LED وأمواج الـ Dot Matrix عند تفعيل `@media (prefers-reduced-motion: reduce)`.
- **التباين**: الحفاظ على نسبة تباين لا تقل عن `4.5:1` لجميع النصوص فوق الخلفيات العتادية `#131313`.
- **Haptic Feedback API**: استدعاء `navigator.vibrate(20)` عند النقر على مفاتيح التبديل الفيزيائية وأزرار Solo/Mute.
