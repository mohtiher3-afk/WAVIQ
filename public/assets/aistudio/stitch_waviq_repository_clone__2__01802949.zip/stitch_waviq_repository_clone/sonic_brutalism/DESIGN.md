---
name: Sonic Brutalism
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e8bcb7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#af8783'
  outline-variant: '#5e3f3b'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690005'
  primary-container: '#ff5449'
  on-primary-container: '#5c0004'
  inverse-primary: '#c00011'
  secondary: '#c6c6c6'
  on-secondary: '#2f3131'
  secondary-container: '#454747'
  on-secondary-container: '#b5b5b5'
  tertiary: '#c8c6c5'
  on-tertiary: '#303030'
  tertiary-container: '#929090'
  on-tertiary-container: '#2a2a2a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000a'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c6'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e4e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474746'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.04em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-md:
    fontFamily: Geist
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Space Mono
    fontSize: 0.875rem
    fontWeight: '700'
    lineHeight: 1.25rem
    letterSpacing: 0.08em
  label-md:
    fontFamily: Space Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Space Mono
    fontSize: 0.625rem
    fontWeight: '400'
    lineHeight: 0.875rem
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels an uncompromising industrial aesthetic built for audio engineers, sound designers, and acoustic researchers. Rooted in translucent hardware casing, mechanical switchgear, and raw telemetry, the visual language merges stark monochrome brutalism with micro-precision functionalism. 

Every view evokes high-end modular synthesizers and transparent audio architecture: pure darkness punctuated by laser-etched white characters, mechanical matrix displays, illuminated glyph contours, and targeted electric red indicators that signify live status, recording, and critical decibel clipping. Interaction patterns mirror tactile studio consoles, offering exact mechanical feedback, clinical structural borders, and purposeful luminescent accents.

## Colors

The palette operates on absolute values to replicate hardware panels in a dark control room:

- **Primary (`#ff2a2a`)**: The signature electric alert red. Strictly reserved for live states, active signal meters, clip indicators, record arming, and active cursor needles. Never diluted or used for non-critical aesthetic fill.
- **Secondary (`#e5e5e5`)**: Pure tactile white-smoke. Powers high-priority typography, vital numeric readouts, active toggle states, and precision reticles.
- **Tertiary (`#262626`)**: Anodized chassis graphite. Powers structural outlines, inactive switch tracks, knob detents, and secondary panel boundaries.
- **Neutral (`#0a0a0a`)**: The primary deep chassis black, backed by pure OLED black (`#000000`) for absolute floor depth and maximum optical contrast.

Supporting utility shades include `#737373` for structural telemetry and unselected matrix dots, and `#141414` with variable alpha for translucent smoked-glass container surfaces.

## Typography

The typographic hierarchy enforces strict industrial discipline:

- **Headlines (Space Grotesk)**: Geometric, technical, and condensed. Used exclusively in uppercase or sentence case with tight tracking to mimic screen-printed hardware panels.
- **Body & Structural Text (Geist)**: Pure low-friction neutral utility. Used for descriptions, documentation, and dense workflow parameters where rapid reading is paramount.
- **Telemetry & Readouts (Space Mono)**: Fixed-pitch precision. Assigned to all decibel measurements, hertz values, sample rates, timestamps, and dot-matrix matrix labels. All telemetry must maintain tabular alignment (`font-variant-numeric: tabular-nums`).
- **Matrix Style**: Display headers and state alerts can leverage dot-matrix emulation by injecting spaced dot-grid typography filters or dot-based SVG matrices for track numbers and DSP status codes.

## Layout & Spacing

The structural layout uses an engineered 12-column fluid modular grid bounded by rigid technical parameters:

- **Desktop (>= 1280px)**: 12 columns, 24px (`1.5rem`) gutters, 32px (`2rem`) outer canvas margins. Multi-rack layout with side-docked master telemetry and horizontal multi-track sequencing.
- **Tablet (768px - 1279px)**: 8 columns, 16px (`1rem`) gutters, 24px (`1.5rem`) outer margin. Dynamic collapsible inspector and stacked DSP modules.
- **Mobile (< 768px)**: 4 columns, 12px gutters, 16px (`1rem`) outer margins. Single-channel strip vertical stack with swipable rack interfaces.
- **Dot-Grid Canvas Overlay**: Underlying views utilize a 16px × 16px repeating dot-grid pattern (`#262626` dots at 1px radius with 35% opacity) to provide hardware alignment references for modular blocks and waveform nodes.

## Elevation & Depth

Visual hierarchy rejects conventional fuzzy diffuse drop shadows in favor of translucent physical layering and edge luminescence:

- **Base Layer (Chassis)**: Solid `#000000` to `#0a0a0a` matte background.
- **Translucent Tier 1 (Smoked Acrylic)**: Cards and rack enclosures use `rgba(18, 18, 18, 0.65)` with a backdrop blur of `16px` to `24px` and a razor-thin border of `1px solid rgba(255, 255, 255, 0.08)`.
- **Translucent Tier 2 (Floating Pods & Popovers)**: `rgba(26, 26, 26, 0.85)` with `20px` backdrop blur and `1px solid rgba(255, 255, 255, 0.18)`.
- **Glyph Luminescence**: Elevated emphasis is delivered through edge lightstrips rather than surface elevation. Active selections, meter envelopes, and active modules display a crisp light guide effect: a `1px` high-contrast outline accompanied by a narrow directional glow (`0 0 10px rgba(255, 255, 255, 0.35)` or `0 0 12px rgba(255, 42, 42, 0.45)` for primary alerts).

## Shapes

The design system employs a soft-industrial radius profile (Rating: `1`). Corner radii remain tightly constrained (`4px` / `0.25rem` standard, `8px` / `0.5rem` for major modules) to evoke CNC-milled aluminum chassis and molded polycarbonate cassettes. 

Full pill geometry is strictly isolated to tactile toggle pins, track status beads, and segmented LED elements. Angular chamfers (45-degree micro-corners) are permitted on telemetry badges, matrix displays, and fader caps to reinforce physical test-equipment heritage.

## Components

### Buttons & Switches
- **Primary Action (Record / Transmit)**: Jet-black surface (`#0a0a0a`), `1px solid #ff2a2a`, text in `#ff2a2a` with Space Mono font. On active hover/click, fills entirely with `#ff2a2a` and flips text to `#000000`.
- **Mechanical Toggle Switch**: Pill-shaped track (`#141414`) bordered with `1px solid #262626`. Actuator peg features an internal illuminated white dot (`#ffffff`) when engaged, shifting to `#ff2a2a` when routing live inputs.
- **Secondary Pushbuttons**: Translucent backing (`rgba(255, 255, 255, 0.04)`), `1px solid rgba(255, 255, 255, 0.12)`, text `#e5e5e5`.

### Chips & Parameter Tags
- Monospaced, uppercase micro-chips with `4px` radius.
- Background: `rgba(255, 255, 255, 0.03)` with `1px solid #262626`.
- Value tags display labels in muted gray (`#737373`) and active parameters in stark white (`#e5e5e5`) or electric red (`#ff2a2a`) when overdriven.

### Inputs & Rotary Knobs
- **Numerical Telemetry Fields**: Bordered bottom-only or fully enclosed micro-frames with monospaced inputs, displaying units (`dB`, `Hz`, `ms`) locked in `#737373`.
- **Rotary Potentiometers**: Circular track in `#1a1a1a` etched with tick-marks. Value fill is an unbroken white light guide arc ending in a singular illuminated red bead at current trim levels.

### Checkboxes & Segmented Radios
- **Checkboxes**: Precise `14px × 14px` squares with a `2px` radius. Active state renders a centered `4px × 4px` solid white or red square rather than a checkmark, echoing status diodes.
- **Segmented Radio Bars**: Monolithic blocks split by `1px` gaps. Active slot switches to stark white background with inverted black Space Mono typography.

### Cards, Modules & Waveform Racks
- Enclosed within smoked glass modules with dot-matrix track identification headers (`CH-01`, `BUS-L`, `MSTR`).
- Top-right corner houses an integrated Glyph indicator strip (a white 2px horizontal pill that pulses smoothly according to audio envelope input).

### VU & Peak Meters
- Vertical and horizontal segment arrays composed of distinct LED dots or blocks spaced 2px apart.
- Levels from `-∞` to `-6dB` illuminate in `#e5e5e5`; `-6dB` to `-1dB` illuminate in `#ffffff` with ambient backlight; `0dB` and clipping zone ignite instantly in piercing `#ff2a2a`.